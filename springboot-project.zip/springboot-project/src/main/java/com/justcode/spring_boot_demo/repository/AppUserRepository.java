package com.justcode.spring_boot_demo.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.justcode.spring_boot_demo.entity.AppUser;
public interface AppUserRepository extends JpaRepository<AppUser,Long>{
Optional<AppUser> findByEmail(String email);
}
