package com.justcode.spring_boot_demo.security;
import jakarta.servlet.*;import jakarta.servlet.http.*;import lombok.RequiredArgsConstructor;import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;import org.springframework.security.core.authority.AuthorityUtils;import org.springframework.security.core.context.SecurityContextHolder;import org.springframework.stereotype.Component;import org.springframework.web.filter.OncePerRequestFilter;import java.io.IOException;
@Component @RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
private final JwtService jwtService;
@Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain)throws ServletException,IOException{
String auth=request.getHeader("Authorization");
if(auth!=null && auth.startsWith("Bearer ")){
String token=auth.substring(7);
String email=jwtService.extractEmail(token);
var authentication=new UsernamePasswordAuthenticationToken(email,null,AuthorityUtils.NO_AUTHORITIES);
SecurityContextHolder.getContext().setAuthentication(authentication);
}
chain.doFilter(request,response);
}
}
