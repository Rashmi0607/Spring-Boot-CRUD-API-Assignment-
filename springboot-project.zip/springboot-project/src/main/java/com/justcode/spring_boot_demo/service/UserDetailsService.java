package com.justcode.spring_boot_demo.service;
import java.util.*;import com.justcode.spring_boot_demo.dto.UserDetailsDto;import com.justcode.spring_boot_demo.entity.UserDetailsEntity;
public interface UserDetailsService {
UserDetailsEntity create(UserDetailsDto dto);
List<UserDetailsEntity> getAll();
UserDetailsEntity update(Long id,UserDetailsDto dto);
void delete(Long id);
}
