package com.justcode.spring_boot_demo.security;
import io.jsonwebtoken.*;import io.jsonwebtoken.security.Keys;import org.springframework.stereotype.Service;import java.security.Key;import java.util.*;
@Service
public class JwtService {
private static final String SECRET="mysecretkeymysecretkeymysecretkey12";
private final Key key=Keys.hmacShaKeyFor(SECRET.getBytes());
public String generateToken(String email){return Jwts.builder().setSubject(email).setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis()+86400000)).signWith(key,SignatureAlgorithm.HS256).compact();}
public String extractEmail(String token){return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody().getSubject();}
}
