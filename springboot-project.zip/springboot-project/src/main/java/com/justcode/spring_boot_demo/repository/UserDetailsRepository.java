package com.justcode.spring_boot_demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.justcode.spring_boot_demo.entity.UserDetailsEntity;
public interface UserDetailsRepository extends JpaRepository<UserDetailsEntity,Long>{}
