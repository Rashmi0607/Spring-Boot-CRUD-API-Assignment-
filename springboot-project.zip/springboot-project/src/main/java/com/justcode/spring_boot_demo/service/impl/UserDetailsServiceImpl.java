package com.justcode.spring_boot_demo.service.impl;
import java.util.*;import org.springframework.stereotype.Service;import lombok.RequiredArgsConstructor;
import com.justcode.spring_boot_demo.dto.UserDetailsDto;import com.justcode.spring_boot_demo.entity.UserDetailsEntity;import com.justcode.spring_boot_demo.repository.UserDetailsRepository;import com.justcode.spring_boot_demo.service.UserDetailsService;
@Service @RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
private final UserDetailsRepository repo;
public UserDetailsEntity create(UserDetailsDto dto){ UserDetailsEntity e=map(dto,new UserDetailsEntity()); return repo.save(e);} 
public List<UserDetailsEntity> getAll(){ return repo.findAll(); }
public UserDetailsEntity update(Long id,UserDetailsDto dto){ UserDetailsEntity e=repo.findById(id).orElseThrow(); return repo.save(map(dto,e)); }
public void delete(Long id){ repo.deleteById(id);} 
private UserDetailsEntity map(UserDetailsDto d,UserDetailsEntity e){e.setName(d.getName());e.setEmail(d.getEmail());e.setCountryCode(d.getCountryCode());e.setPhone(d.getPhone());e.setAddress(d.getAddress());e.setPdfUpload(d.getPdfUpload());e.setVideoUpload(d.getVideoUpload()); return e;}
}
