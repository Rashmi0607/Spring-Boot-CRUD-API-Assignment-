package com.justcode.spring_boot_demo.entity;
import jakarta.persistence.*;import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Table(name="user_details")
public class UserDetailsEntity {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
private String name;
private String email;
private String countryCode;
private String phone;
private String address;
private String pdfUpload;
private String videoUpload;
}
