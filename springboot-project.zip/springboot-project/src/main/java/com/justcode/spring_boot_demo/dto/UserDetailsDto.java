package com.justcode.spring_boot_demo.dto;
import lombok.*;
@Getter @Setter
public class UserDetailsDto {
private String name; private String email; private String countryCode; private String phone; private String address; private String pdfUpload; private String videoUpload;
}
