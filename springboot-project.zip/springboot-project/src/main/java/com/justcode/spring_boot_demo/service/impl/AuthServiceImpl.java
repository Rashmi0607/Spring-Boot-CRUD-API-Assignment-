package com.justcode.spring_boot_demo.service.impl;
import com.justcode.spring_boot_demo.dto.AuthRequest;import com.justcode.spring_boot_demo.entity.AppUser;import com.justcode.spring_boot_demo.repository.AppUserRepository;import com.justcode.spring_boot_demo.security.JwtService;import com.justcode.spring_boot_demo.service.AuthService;import lombok.RequiredArgsConstructor;import org.springframework.security.crypto.password.PasswordEncoder;import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
private final AppUserRepository repo; private final PasswordEncoder encoder; private final JwtService jwtService;
public String register(AuthRequest request){
AppUser user=new AppUser(); user.setEmail(request.getEmail()); user.setPassword(encoder.encode(request.getPassword())); repo.save(user); return jwtService.generateToken(user.getEmail());
}
public String login(AuthRequest request){
AppUser user=repo.findByEmail(request.getEmail()).orElseThrow();
if(!encoder.matches(request.getPassword(), user.getPassword())) throw new RuntimeException("Invalid credentials");
return jwtService.generateToken(user.getEmail());
}
}
