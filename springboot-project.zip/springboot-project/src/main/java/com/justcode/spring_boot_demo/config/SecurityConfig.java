package com.justcode.spring_boot_demo.config;
import com.justcode.spring_boot_demo.security.JwtFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;import org.springframework.security.config.annotation.web.builders.HttpSecurity;import org.springframework.security.config.http.SessionCreationPolicy;import org.springframework.security.crypto.bcrypt.*;import org.springframework.security.crypto.password.PasswordEncoder;import org.springframework.security.web.*;import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
@Configuration @RequiredArgsConstructor
public class SecurityConfig {
private final JwtFilter jwtFilter;
@Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
@Bean SecurityFilterChain securityFilterChain(HttpSecurity http)throws Exception{
http.csrf(csrf->csrf.disable()).sessionManagement(sm->sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS)).authorizeHttpRequests(auth->auth.requestMatchers("/api/auth/**").permitAll().anyRequest().authenticated()).addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
return http.build();
}
}
