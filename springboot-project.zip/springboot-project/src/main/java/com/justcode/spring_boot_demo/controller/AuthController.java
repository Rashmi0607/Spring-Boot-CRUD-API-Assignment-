package com.justcode.spring_boot_demo.controller;
import org.springframework.web.bind.annotation.*;import lombok.RequiredArgsConstructor;
import com.justcode.spring_boot_demo.dto.*;import com.justcode.spring_boot_demo.service.AuthService;
@RestController @RequestMapping("/api/auth") @RequiredArgsConstructor
public class AuthController {
private final AuthService service;
@PostMapping("/register")
public AuthResponse register(@RequestBody AuthRequest request){ return new AuthResponse(service.register(request)); }
@PostMapping("/login")
public AuthResponse login(@RequestBody AuthRequest request){ return new AuthResponse(service.login(request)); }
}
