package com.justcode.spring_boot_demo.service;
import com.justcode.spring_boot_demo.dto.*;
public interface AuthService {
String register(AuthRequest request);
String login(AuthRequest request);
}
