package com.justcode.spring_boot_demo.dto;
import lombok.*;
@AllArgsConstructor @Getter
public class AuthResponse { private String token; }
