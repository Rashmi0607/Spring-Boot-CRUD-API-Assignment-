package com.justcode.spring_boot_demo.dto;
import lombok.*;
@Getter @Setter
public class AuthRequest { private String email; private String password; }
