package com.justcode.spring_boot_demo.controller;
import java.util.*;import org.springframework.web.bind.annotation.*;import lombok.RequiredArgsConstructor;
import com.justcode.spring_boot_demo.dto.UserDetailsDto;import com.justcode.spring_boot_demo.entity.UserDetailsEntity;import com.justcode.spring_boot_demo.service.UserDetailsService;
@RestController @RequestMapping("/api/details") @RequiredArgsConstructor
public class UserDetailsController {
private final UserDetailsService service;
@PostMapping public UserDetailsEntity create(@RequestBody UserDetailsDto dto){ return service.create(dto); }
@GetMapping public List<UserDetailsEntity> getAll(){ return service.getAll(); }
@PutMapping("/{id}") public UserDetailsEntity update(@PathVariable Long id,@RequestBody UserDetailsDto dto){ return service.update(id,dto); }
@DeleteMapping("/{id}") public String delete(@PathVariable Long id){ service.delete(id); return "Deleted Successfully"; }
}
