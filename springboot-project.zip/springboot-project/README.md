# Fixed Spring Boot Project

Use Java 21 and Maven to run the project.
